CrowdStrike CrowdRE Plugin for IDA Pro 6.3.120531
CrowdRE version 1.0.8.0 alpha

LICENSE

Please see CrowdRE_EULA.txt for complete licensing details.  

Some portions of this software are redistributed from 3rd parties and come with their own
licenses; please see the appropriate license files for details.

INSTALLATION INSTRUCTIONS

1. Copy crowdre.plw, crowdre.p64, and crowdstrike.pem from the CrowdRE zip to the 
   IDA\plugins folder.

2.  Launch IDA.  You can use the CrowdRE plugin by pressing CTRL+F2.

KNOWN ISSUES

Cyclic dependencies: Due to a limitation in our interworking with IDA, annotations with cyclic
dependencies cannot be imported (they will cause a parse failure).  We can detect such
annotations and will warn you that they cannot be saved to the cloud; we are investigating
a better fix.

Some stack variables not uploaded to cloud: If Hex-Rays recognizes a stack variable but IDA does
not, annotations to that variable will not be uploaded to the cloud.  To work around this, fix 
up the stack view in IDA manually before uploading annotations. This seems to be new since
the IDA 6.3 release.

Need to reopen CrowdRE window to refresh auth token: If your authentication token is 
invalid, you will get a dialog which informs you so.  You will have to close and re-open the 
CrowdRE window to enter a new token. We are working on a fix that provides a niceer workflow.

CrowdRE window is synchronized to IDA view: If you have Hex-Rays installed and you are in the
Hex-Rays pseudocode window, you can press Ctrl-F2 to open CrowdRE; but if your IDA view is on
a different function than your Hex-Rays view, you will be offered annotations relevant to the 
IDA view, not the Hex-Rays view.

